from django.apps import AppConfig


class ChatbotInterfaceConfig(AppConfig):
    name = 'chatbot_interface'
